const Item= require('../models/item');

const showchanges= async()=>{
    const changestream= Item.watch();

    changestream.on("change",(change)=>{
        console.log("changes detected: ",change);
    });

    changestream.on("error",(error)=>{
        console.log("error occured: ", error);
    });



}
module.exports=showchanges;